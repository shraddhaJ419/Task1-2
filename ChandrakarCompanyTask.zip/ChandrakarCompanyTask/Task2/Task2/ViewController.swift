//
//  ViewController.swift
//  Task2
//
//  Created by Shraddha  on 18/07/23.
//

import UIKit
import AVFoundation
import Foundation

class ViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    var isChecked = true
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func check1(_ sender: UIButton) {
        //set button capture photo
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            var imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera;
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    @IBAction func check2(_ sender: UIButton) {
        isChecked = !isChecked
        if isChecked {
            toggleTorch(on: true)
//            sender.setTitle("✓", for: .normal)
//            sender.setTitleColor(.green, for: .normal)
        } else {
            toggleTorch(on: false)
//            sender.setTitle("X", for: .normal)
//            sender.setTitleColor(.red, for: .normal)
        }
    }
    func toggleTorch(on: Bool) {
        guard
            let device = AVCaptureDevice.default(for: AVMediaType.video),
            device.hasTorch
        else { return }

        do {
            try device.lockForConfiguration()
            device.torchMode = on ? .on : .off
            device.unlockForConfiguration()
        } catch {
            print("Torch could not be used")
        }
    }
}

