//
//  StandardVC.swift
//  Task1
//
//  Created by Shraddha  on 21/07/23.
//

import UIKit

class StandardVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Standard"

        // Do any additional setup after loading the view.
    }
    

    

}
