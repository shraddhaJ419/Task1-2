//
//  CustomVC.swift
//  Task1
//
//  Created by Shraddha  on 21/07/23.
//

import UIKit

class CustomVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Custom"
        // Do any additional setup after loading the view.
    }
    

    

}
