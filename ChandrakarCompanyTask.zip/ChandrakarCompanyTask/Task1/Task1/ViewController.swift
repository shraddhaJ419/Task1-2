//
//  ViewController.swift
//  Task1
//
//  Created by Shraddha  on 18/07/23.
//

import UIKit
//import Stripe

class ViewController: UIViewController  {
    
    //STPAddCardViewControllerDelegate
    @IBOutlet  weak var submitButton :UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.submitButton.addTarget(self, action: #selector(submitpayment), for: .touchUpInside)
    }

    @objc func submitpayment(){
//        let config = STPPaymentConfiguration()
//        config.requiredBillingAddressFields = .full
//        let viewController = STPAddCardViewController(configuration: config, theme: STPTheme.default())
//        viewController.delegate = self
//        let navigationController = UINavigationController(rootViewController: viewController)
//        present(navigationController, animated: true, completion: nil)
    }
//    func addCardViewControllerDidCancel(_ addCardViewController: Stripe.STPAddCardViewController) {
//        ///
//    }
//
//    func addCardViewController(_ addCardViewController: Stripe.STPAddCardViewController, didCreatePaymentMethod paymentMethod: StripePayments.STPPaymentMethod, completion: @escaping StripePayments.STPErrorBlock) {
//        ///
//    }
}

