//
//  ApplepayVC.swift
//  Task1
//
//  Created by Shraddha  on 21/07/23.
//

import UIKit

class ApplepayVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Apple pay"
        // Do any additional setup after loading the view.
    }
    

   
}
